# xtream-to-url
CLI-based Xtream Codes to URL converter. **Please note that this software does not provide Xtream Codes links.**

# False-positive Warning
Recently Windows Defender detected it as a virus. If you can't use it, download the batch file and run it as usual (double-click the file) - [Download here](https://github.com/weareblahs/xtream-to-url/releases/download/1.0.0.1/XTTURL_code.bat).

# Supported Formats

Playlist: m3u / m3u_plus

Output Type: m3u8 / ts

XMLTV: xmltv (through xmltv.php)

# Required Parameters for generating

- Username

- Password

- Port / Address

- Play Token (if required)

# Post actions

- Open in Chrome (auto-download)

- wget: Download to Desktop (soon)

[Download it here](https://github.com/weareblahs/xtream-to-url/releases/download/1.0.0.1/XTTURL.exe)
