## Archived due to https://covidnow.moh.gov.my
I recommend you to get COVID-19 information through this website as it is a "at-a-glance" style website for COVID-19 information in Malaysia.

# Is There MCO?
A TL;DR page of information on is there Movement Control Order (MCO) in Malaysia or not. Manually updated.

# Where are the sources of this website?
Main Source: https://t.me/cprckkm  
Other sources include Astro Awani, The Star and other reliable news websites based on Malaysia.
