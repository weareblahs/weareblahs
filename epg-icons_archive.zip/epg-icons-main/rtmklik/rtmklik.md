# How to use
Change your channel icon URL in your playlist to "https://weareblahs.github.io/epg-icons/rtmklik/(ChannelNumber).png".
