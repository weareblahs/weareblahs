# TheMiscPCToolbox
Imagine a place where you double-click to do something to your computer. ~Maybe this is a high quality useless project, or another useful one~

# OK, here's the serious explanation
This script is another "double-click-to-run" collection of basic Windows and Linux script. Use it by yourself.
