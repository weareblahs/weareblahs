# unifi TV Proxy originally made by @ohsem - Now in beta testing
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy)
# IPTV
API to retrive IPTV links and informations.
The API is hosted at https://my-iptv.herokuapp.com

### Unifi TV
- m3u8 Provider
  - https://my-iptv.herokuapp.com/m3u8/unifi-tv?userID=${unifi-playTV-userid}&clientPasswd=${unifi-playTV-password}
- EPG
  - https://my-iptv.herokuapp.com/epg/unifi-tv
    - Redirecting to https://github.com/weareblahs/epg/blob/master/unifitv.xml
