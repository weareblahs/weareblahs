## List of channels on unifi TV
| Channel Name | Maximum Resolution | Category | HD | Additional notes | Native Channel Name | Subtitles |
|---|---|---|---|---|---|---|
| TV1 | 1024x576 25fps | Malaysian Variety | Downscaled from HD feed - HD available on MYTV, RTM Klik and Astro | Burn-in subtitles - MYTV Broadcasting has embedded subtitles |
| TV2 | 1024x576 25fps | Malaysian Variety | Downscaled from HD feed - HD available on MYTV, RTM Klik and Astro | Burn-in subtitles - MYTV Broadcasting has embedded subtitles |
| TV3 | 1920x1080 25fps | Malaysian Variety | ✓ | HD available on MYTV Broadcasting |
| DidikTV KPM | 1024x576 25fps | Malaysian Variety | Downscaled from HD feed - HD available on MYTV Broadcasting and Tonton | Previously NTV7 |
| 8TV | 1024x576 25fps | Chinese Variety | Downscaled from HD feed - HD available on MYTV Broadcasting and Tonton | | 八度空间 |
| TV9 | 1024x576 25fps | Malaysian Variety | Downscaled from HD feed - HD available on MYTV Broadcasting and Tonton | HD available on MYTV Broadcasting |
| Salam HD | 1920x1080 25fps | Malaysian Variety | ✓ | unifi TV In-house Channel |
| TV AlHijrah | 1024x576 25fps | Malaysian Variety | Downscaled from HD feed / HD available on MYTV Broadcasting |
| HyppSensasi HD | 1920x1080 25fps | Malaysian Variety | ✓ | unifi TV Exclusive |
| HyppInspirasi HD | 1920x1080 25fps | Malaysian Variety | ✓ | unifi TV In-house Channel |
| Dunia Sinema HD | 1920x1080 25fps | Movies | ✓ | unifi TV In-house Channel |
| Pesona HD | 1920x1080 25fps | Malaysian Variety | ✓ | unifi TV In-house Channel |
| Laku Mall | 1920x1080 25fps | Malaysian Variety | ✓ | unifi TV In-house Channel |
| tvN Movies | 1920x1080 25fps | Movies | ✓ | Southeast Asian Feed | | Chinese, English, Malay |
| SETI | 1024x576 25fps | Chinese Variety | Graphics is 4:3 but channel content are in 16:9 | unifi TV Exclusive in Malaysia | 三立國際台 |
| tvN HD | 1920x1080 25fps | International Variety | ✓ | Southeast Asian Feed | tvN | Chinese, English, Malay |
| SCM Legend HD | 1920x1080 25fps | Movies | ✓ | unifi TV Exclusive in Malaysia | 衛視卡式台 | Chinese / English, Malay |
| SCM HD | 1920x1080 25fps | Movies | ✓ | unifi TV Exclusive in Malaysia | 衛視電影台 | Chinese / English, Malay |
| Star Chinese Channel HD | 1920x1080 25fps | Chinese Variety | ✓ | Asia-Pacific Feed | 衛視中文台 |
| Now Jelli HD | 1920x1080 25fps | Chinese Variety | ✓ | unifi TV Exclusive in Malaysia | nowJelli紫金國際台 |
| Yupp Thirai HD | 1920x1080 25fps | Movies | ✓ | unifi TV Exclusive | Yupp திரை |
| Colors Tamil HD | 1920x1080 25fps | Indian Variety | ✓ | Asia-Pacific Feed | Colors HD தமிழ் |
| Polimer | 1024x576 25fps | Indian Variety | - | Indian Feed, unifi TV Exclusive in Malaysia |
| Jaya Max | 1024x576 25fps | Indian Variety | - | Asia-Pacific Feed, unifi TV Exclusive in Malaysia |
| Sony Max | 1024x576 25fps | Movies | Pan and Scan | Asia-Pacific Feed, Burn in subtitles, unifi TV Exclusive in Malaysia |
| Colors Cineplex | 1024x576 25fps | Movies | Pan and Scan | Asia-Pacific Feed, unifi TV Exclusive in Malaysia |
| Colors | 1024x576 25fps | Indian Variety | Pan and Scan | Asia-Pacific Feed |
| Sony SAB | 1024x576 25fps | Indian Variety | Pan and Scan | Asia-Pacific Feed, Burn in subtitles |
| Sony SET | 1024x576 25fps | Indian Variety | Downscaled from HD Feed | Asia-Pacific Feed, Burn in subtitles | Sony Entertainment Television |
| FOX Movies HD | 1920x1080 25fps | Movies | ✓ | 1 hour delay than other Southeast Asian countries such as Singapore | | Chinese, Malay |
| FOX Action Movies HD | 1920x1080 25fps | Movies | ✓ | 1 hour delay than other Southeast Asian countries such as Singapore | | Chinese, Malay |
| FOX Family Movies HD | 1920x1080 25fps | Movies | ✓ | 1 hour delay than other Southeast Asian countries such as Singapore | | Chinese, Malay |
| Paramount Network | 1920x1080 25fps | Movies | ✓ | Southeast Asian Feed |
| CinemaWorld HD | 1920x1080 25fps | Movies | ✓ | Southeast Asian Feed |  | Chinese, English, Malay |
| Warner TV HD | 1920x1080 25fps | International Variety | ✓ | Southeast Asian Feed |  | Chinese, Malay |
| FOX | 1920x1080 25fps | International Variety | ✓ | 1 hour delay than other Southeast Asian countries such as Singapore | | Chinese, Malay |
| FX | 1920x1080 25fps | International Variety | ✓ | 1 hour delay than other Southeast Asian countries such as Singapore | | Chinese, Malay |
| FOX Life | 1920x1080 25fps | International Variety | ✓ | 1 hour delay than other Southeast Asian countries such as Singapore | | Chinese, Malay |
| Blue Ant Entertainment | 1920x1080 25fps | International Variety | ✓ | Southeast Asian Feed |  | Chinese, Malay |
| Blue Ant Extreme | 1920x1080 25fps | International Variety | ✓ | Southeast Asian Feed |  | Chinese, Malay |
| BBC Earth HD | 1920x1080 25fps | Lifestyle & Knowledge | ✓ | Asian Feed |  | Chinese, Malay |
| Love Nature HD | 1920x1080 25fps | Lifestyle & Knowledge | ✓ (Downscaled from 4K) | Southeast Asian Feed |
| National Geographic HD | 1920x1080 25fps | Lifestyle & Knowledge | ✓ | Southeast Asian Feed | | Chinese, Malay |
| Nat Geo Wild HD | 1920x1080 25fps | Lifestyle & Knowledge | ✓ | Southeast Asian Feed |  | Chinese, Malay |
| Nat Geo People HD | 1920x1080 25fps | Lifestyle & Knowledge | ✓ | Southeast Asian Feed, Will be removed from October 1, 2021 | | Chinese, Malay |
| BBC Lifestyle HD | 1920x1080 25fps | Lifestyle & Knowledge | ✓ | unifi TV Exclusive in Malaysia |
| Travel Channel HD | 1920x1080 25fps | Lifestyle & Knowledge | ✓ | unifi TV Exclusive in Malaysia |
| Luxe.TV HD | 1920x1080 25fps | Lifestyle & Knowledge | ✓ | International Feed |
| MTV Asia | 1920x1080 25fps | Lifestyle & Knowledge | ✓ | 1 hour delay except live programs |
| Dreamworks HD | 1920x1080 25fps | Kids | ✓ | unifi TV Exclusive in Malaysia |
| Nick Jr. | 1920x1080 25fps | Kids | ✓ | Southeast Asian Feed |
| CBeebies HD | 1920x1080 25fps | Kids | ✓ | unifi TV Exclusive in Malaysia |
| Nickelodeon | 1024x576 25fps | Kids | Downscaled from HD | Southeast Asian Feed |
| Boomerang HD | 1920x1080 25fps | Kids | ✓ | Southeast Asian Feed |
| Baby TV HD | 1920x1080 25fps | Kids | ✓ | Will be removed on October 1, 2021 |
| BBC World News HD | 1920x1080 25fps | News | ✓ | International Feed |
| Al Jazeera | 1920x1080 25fps | News | ✓ | International Feed |
| Sky News HD | 1920x1080 25fps | News | ✓ | International Feed |
| Channel NewsAsia | 1024x576 25fps | News | Downscaled from HD feed | International Feed |
| Euronews | 1024x576 25fps | News | Downscaled from HD feed, unifi TV Exclusive in Malaysia | Europe Feed |
| BNC | 1024x576 25fps | News | - | | Bernama News Channnel |
| Parlimen Malaysia | 1920x1080 25fps | News | ✓ | unifi TV Exclusive |
| ABC Australia | 1024x576 25fps | News | - | International Feed|
| DW | 1920x1080 25fps | News | Upscaled from SD feed |
| NHK WORLD-JAPAN | 1920x1080 25fps | News | ✓ | International Feed |
| France24 | 1920x1080 25fps | News | ✓ | France feed |
| unifi Sports 1 | 1920x1080 25fps | Sports | ✓ | unifi TV In-house Channel |
| unifi Sports 2 | 1920x1080 25fps | Sports | ✓ | unifi TV In-house Channel |
| unifi Sports 3 | 1920x1080 25fps | Sports | ✓ | unifi TV In-house Channel |
| unifi Sports 4 | 1920x1080 25fps | Sports | ✓ | unifi TV In-house Channel |
| unifi Sports 5 | 1920x1080 25fps | Sports | ✓ | unifi TV In-house Channel |
| FOX Sports 1 | 1920x1080 25fps | Sports | ✓ | Will be removed on October 1, 2021 |
| FOX Sports 2 | 1920x1080 25fps | Sports | ✓ | Will be removed on October 1, 2021 |
| FOX Sports 3 | 1920x1080 25fps | Sports | ✓ | Will be removed on October 1, 2021 |
| unifi TV | 1920x1080 25fps | Preview Channel | ✓ | HyppFlicks+ Preview Channel |
| 988 | AAC 64Kbps | Radio Stations | Audio only | Livestream feed taken from official website |
| Suria FM | AAC 64Kbps | Radio Stations | Audio only | Livestream feed taken from official website |

## Pop-up Channels
| Channel Name | Maximum Resolution | Category | HD | Additional Notes | Channel Availability Period |
|---|---|---|---|---|---|
| unifi Sports 6 | 1920x1080 25fps | Tokyo 2020 Olympics | ✓ | unifi TV In-house Pop-up Channel - currently for the Tokyo 2020 Olympics | 20 July 2021 - 11 August 2021 |
| unifi Sports 7 | 1920x1080 25fps | Tokyo 2020 Olympics | ✓ | unifi TV In-house Pop-up Channel - currently for the Tokyo 2020 Olympics | 20 July 2021 - 11 August 2021 |
| unifi Sports 8 | 1920x1080 25fps | Tokyo 2020 Olympics | ✓ | unifi TV In-house Pop-up Channel - currently for the Tokyo 2020 Olympics | 20 July 2021 - 11 August 2021 |
| unifi Sports 9 | 1920x1080 25fps | Tokyo 2020 Olympics | ✓ | unifi TV In-house Pop-up Channel - currently for the Tokyo 2020 Olympics | 20 July 2021 - 11 August 2021 |
| unifi Sports 10 | 1920x1080 25fps | Tokyo 2020 Olympics | ✓ | unifi TV In-house Pop-up Channel - currently for the Tokyo 2020 Olympics | 20 July 2021 - 11 August 2021 |
| unifi Sports 11 | 1920x1080 25fps | Tokyo 2020 Olympics | ✓ | unifi TV In-house Pop-up Channel - currently for the Tokyo 2020 Olympics | 20 July 2021 - 11 August 2021 |
| unifi Sports 12 | 1920x1080 25fps | Tokyo 2020 Olympics | ✓ | unifi TV In-house Pop-up Channel - currently for the Tokyo 2020 Olympics | 20 July 2021 - 11 August 2021 |
| unifi Sports 13 | 1920x1080 25fps | Tokyo 2020 Olympics | ✓ | unifi TV In-house Pop-up Channel - currently for the Tokyo 2020 Olympics | 20 July 2021 - 11 August 2021 |
