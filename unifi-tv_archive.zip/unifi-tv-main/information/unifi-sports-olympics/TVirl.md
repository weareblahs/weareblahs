## TVirl instructions: Update channels
### Part 1: Update Playlist
1. Open "Live Channels" on your Android TV device, then press the "enter" button to open the menu. Then, navigate to "Settings" (TVirl Settings).
![WIN_20210709_10_44_25_Pro](https://user-images.githubusercontent.com/37889443/125016030-3b0e0e00-e0a3-11eb-9f68-a3ca5d63b351.jpg)
2. Select "Main Menu".
![WIN_20210709_10_44_31_Pro](https://user-images.githubusercontent.com/37889443/125016033-3d706800-e0a3-11eb-9c22-99c022cdcf62.jpg)
3. Select "Channels".
![WIN_20210709_10_44_37_Pro](https://user-images.githubusercontent.com/37889443/125016037-3ea19500-e0a3-11eb-9120-b97602caba1d.jpg)
4. Select "Reload Current Playlist".
![WIN_20210709_10_44_46_Pro](https://user-images.githubusercontent.com/37889443/125016039-3f3a2b80-e0a3-11eb-8b44-34b2a5ec0166.jpg)
5. Let TVirl update the channel list. After update, select "TV!". (Donators who paid for TVirl can select "Auto Update" then follow the on-screen instructions)
![WIN_20210709_10_45_02_Pro](https://user-images.githubusercontent.com/37889443/125016049-4103ef00-e0a3-11eb-8107-a4b23bda6dcd.jpg)
### Part 2: Update Channels (Donators can skip this part and directly watch it on Live Channels)
6. When you return to "Live Channels", press "Enter", then "Down" for two times, then navigate to "Settings" (Live Channels Settings).
![WIN_20210709_10_45_29_Pro](https://user-images.githubusercontent.com/37889443/125016054-419c8580-e0a3-11eb-8451-d88c6d63c008.jpg)
7. Select "Customize Channels".
![WIN_20210709_10_45_34_Pro](https://user-images.githubusercontent.com/37889443/125016058-43664900-e0a3-11eb-8806-9568595f04aa.jpg)
8. Tick all the unticked "unifi Sports" channels and you're ready to watch!
![WIN_20210709_10_45_42_Pro](https://user-images.githubusercontent.com/37889443/125016062-44977600-e0a3-11eb-9bd9-520413b5abba.jpg)
  
  **NOTE: After the event ends, you have to follow Part 1 again in order to let these channels gone.**
