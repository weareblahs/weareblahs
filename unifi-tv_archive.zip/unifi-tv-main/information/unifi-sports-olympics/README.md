![](https://www.tm.com.my/tv/assets/imgs/everywhere/unifi_Olympic.jpg)
# How to watch it in this playlist?
You can watch it through the "Tokyo 2020 Olympics" category on the playlist. If you're using PVR Live or TVirl, the channel numbers were listed below:
| Channel Number  | Channel Name  | Permanent / Pop-up Channel | Category |
|---|---|---|---|
| 701  | unifi Sports 1  | Permanent | Sports: Tokyo 2020 Olympics |
| 702  | unifi Sports 2  | Permanent | Sports: Tokyo 2020 Olympics |
| 703  | unifi Sports 3  | Permanent | Sports: Tokyo 2020 Olympics |
| 704  | unifi Sports 4  | Permanent | Sports: Tokyo 2020 Olympics |
| 705  | unifi Sports 5  | Permanent | Sports: Tokyo 2020 Olympics |
| 709  | unifi Sports 6  | Pop-up Channel | Sports: Tokyo 2020 Olympics |
| 710  | unifi Sports 7  | Pop-up Channel | Sports: Tokyo 2020 Olympics |
| 711  | unifi Sports 8  | Pop-up Channel | Sports: Tokyo 2020 Olympics |
| 712  | unifi Sports 9  | Pop-up Channel | Sports: Tokyo 2020 Olympics |
| 713  | unifi Sports 10  | Pop-up Channel | Sports: Tokyo 2020 Olympics |
| 714  | unifi Sports 11  | Pop-up Channel | Sports: Tokyo 2020 Olympics |
| 715  | unifi Sports 12  | Pop-up Channel | Sports: Tokyo 2020 Olympics |
| 716  | unifi Sports 13  | Pop-up Channel | Sports: Tokyo 2020 Olympics |

The unifi Sports channels on the "Sports" category will be changed to "Tokyo 2020 Olympics" category during this period. This won't affect FOX Sports channels (Ch 706-708).

## Troubleshooting
If you see this screen now on the channels stated above:
![Background](https://user-images.githubusercontent.com/37889443/124946613-bfc84000-e041-11eb-9f85-9b662a215b44.png)
then you have to update your playlist in your IPTV client. Here is the tutorial of how to update playlist on TiviMate:
1. First, press "back" to go to the channel guide screen, then press "left" for two times until you see this screen:
![WIN_20210708_23_19_15_Pro](https://user-images.githubusercontent.com/37889443/124948159-079b9700-e043-11eb-8fdb-8368634bc0fd.jpg)
Select "Settings".
2. Select "Playlist".
![WIN_20210708_23_19_20_Pro](https://user-images.githubusercontent.com/37889443/124948170-0a968780-e043-11eb-9a29-8047b080353c.jpg)
3. Select "Update all playlists".
![WIN_20210708_23_19_26_Pro](https://user-images.githubusercontent.com/37889443/124948179-0bc7b480-e043-11eb-9e85-bc9e029abc3e.jpg)
Additional step: if you want to update the EPG, go back, then select EPG, then select "Update EPG".
![WIN_20210708_23_19_36_Pro](https://user-images.githubusercontent.com/37889443/124948187-0cf8e180-e043-11eb-80c5-d50c52dc1c80.jpg)
