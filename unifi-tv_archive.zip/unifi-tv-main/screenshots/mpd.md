[Used Extension](https://chrome.google.com/webstore/detail/native-mpeg-dash-+-hls-pl/cjfbmleiaobegagekpmlhmaadepdeedn?hl=en)  
![TV3 (Full HD, Native Resolution)](https://i.ibb.co/cQfm0jw/image.png "TV3 (Full HD, Native Resolution)")  TV3 (Full HD, Native Resolution)  
![Love Nature 4K (Full HD, Native Resolution)](https://i.ibb.co/bRbDVXP/image.png "Love Nature 4K (Full HD, Native Resolution)")  Love Nature 4K (Full HD, Native Resolution)  
![Dreamworks HD (Full HD, Native Resolution)](https://i.ibb.co/mqJsJGG/image.png "Dreamworks HD (Full HD, Native Resolution)")  Dreamworks HD (Full HD, Native Resolution)
