### Why taken using phone?
Because due to DRM restrictions, only the subtitles can be captured through Tivimate.  
![nor](https://i.ibb.co/VB33ncW/nor.jpg "nor.jpg")  Nat Geo People HD (Subtitles: "Chinese, Alternative" - Traditional Chinese)  
![nor](https://i.ibb.co/w6BSTJ2/nor.jpg "nor.jpg")  TVN (Subtitles: "English" - English)  
![nor](https://i.ibb.co/xH4H4Qg/nor.jpg "nor.jpg")  BBC Earth HD (Subtitles "Malay" - Malay)  
