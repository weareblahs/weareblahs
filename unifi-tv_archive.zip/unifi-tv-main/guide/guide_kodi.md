# Before you start
## Requirements for devices
 - Android TV
   - Latest Kodi version from Google Play Store
 - Raspberry Pi
   - LibreELEC 9.2.8 or up. This version fixes Widevine problems. If using newer version it might return maximum 360p.
 - Windows
   - Recommend using Matrix 19.1
## Stuffs that you might want to install before starting these steps
 - PVR IPTV Simple Client
 - SlyGuy Repository
   - Instructions on how to install it [here](https://www.matthuisman.nz/2020/02/slyguy-kodi-repository.html)

# Part 1: Getting the Widevine CDM on Kodi
1. Go to Settings > Add-ons > Install from Repository > SlyGuy Repository > Video Add-ons > Video Test Streams.
![WIN_20210814_19_50_03_Pro](https://user-images.githubusercontent.com/37889443/129445416-30a1743b-a09b-445d-883e-e8bbcba61ef5.jpg)
2. Select "Install" and open it.
![WIN_20210814_19_52_45_Pro](https://user-images.githubusercontent.com/37889443/129445435-044514a1-3cfe-4357-8085-42edc95d992c.jpg)
3. Select Settings > Install Widevine CDM.
![WIN_20210814_19_53_50_Pro](https://user-images.githubusercontent.com/37889443/129445459-68bd2359-ea48-454c-8bfb-f8539773a3c0.jpg)
4. Select the latest one.
![WIN_20210814_19_54_20_Pro](https://user-images.githubusercontent.com/37889443/129445469-156981c1-c1ce-4435-b541-5a9179b4528e.jpg)
5. After downloading, select OK.
![WIN_20210814_19_55_07_Pro](https://user-images.githubusercontent.com/37889443/129445497-0efac178-258d-4195-b850-43eaf2847ea7.jpg)
6. You can test it by selecting "InputStream Adaptive - Dash with Widevine". This is the same one that we will use with the playlist.
![WIN_20210814_19_55_29_Pro](https://user-images.githubusercontent.com/37889443/129445503-0f13e01f-d562-40b1-a195-e0b2e01b2d2f.jpg)
 - It should appear like this:
![WIN_20210814_19_56_26_Pro](https://user-images.githubusercontent.com/37889443/129445528-1cc8e8ca-d5fc-4526-bac3-ed8d6930301d.jpg)

# Part 2: The Playlist
1. Back to Home Screen, then go to Settings > Add-ons > Install from Repository > All Repositories > PVR clients > PVR IPTV Simple Client > Install. After this, go to Configure. It will appear this:
![WIN_20210814_20_00_13_Pro](https://user-images.githubusercontent.com/37889443/129445618-7dac6d0b-eee7-4ff4-b03c-137b141f9dbe.jpg)
2. Go to "M3U Playlist URL" then type in the generated URL. Then, turn off "Cache m3u at local storage" (because it will update at real time).
![WIN_20210814_20_00_13_Pro](https://user-images.githubusercontent.com/37889443/129445796-cea2fb41-4886-4089-a97b-9a5580204acc.jpg)
3. Go to "Auto Refresh Mode" > "Once per day".
![WIN_20210814_20_07_42_Pro](https://user-images.githubusercontent.com/37889443/129445846-8f3abdb6-64ad-48f6-81db-141358bc14d3.jpg)
4. Then, go to EPG. Change the XMLTV URL to `https://unifiplaytv.samsam123.tk/epg` and turn off "Cache XMLTV at local storage".
![WIN_20210814_20_09_25_Pro](https://user-images.githubusercontent.com/37889443/129445877-5b4451a6-9d95-47c7-8649-abee94fc4d35.jpg)
5. Select "OK" > Reboot device / Exit, then open Kodi again. After this, go to TV and you're ready to watch!
![WIN_20210814_20_13_00_Pro](https://user-images.githubusercontent.com/37889443/129445966-1f75d546-b597-4182-aacd-6b22454d91a7.jpg)
