# Notice
## As the backend of ``unifiplaytv.samsam123.tk`` has been reported as copyright infrigement, we decided to archive this repository due to legal concerns. EPG and Freeview repositories will continue as normal. Thanks for using this playlist.

# What's this repository all about?
This repository is for watching unifi TV on IPTV clients other than the official unifi TV app. See "What's this?" for more detailed info.
## Temporary Fix: September 12
This playlist can be played through Kodi for some Android Devices through Microsoft Playready.
## IMPORTANT UPDATE: September 11
This playlist can't be played on both playtv.unifi.com.my and this playlist, becuase the playlist content is also taken from their web app, so it can't be watched now. unifi TV Subscribers can still watch through the official unifi TV App or playtv@unifi.
## Update: September 10
unifi TV (Ch 100) will be removed from this playlist as this channel is not available now on the playtv@unifi / unifi TV app.

# TL;DR: How to get the playlist?
Use the following URL format on your IPTV client:  
``https://unifiplaytv.samsam123.tk/m3u8/unifi-tv?userID=(Your Phone Number)&clientPasswd=(Your playtv@unifi Password)``  or  ``https://my-iptv.herokuapp.com/m3u8/unifi-tv?userID=(Your Phone Number)&clientPasswd=(Your playtv@unifi Password)``  
For Kodi, use ``https://unifiplaytv.samsam123.tk/m3u8-kodi/unifi-tv?userID=(Your Phone Number)&clientPasswd=(Your playtv@unifi Password)``  
Or a more user-friendly version, where you just have to type in your username / password, then click / tap "Generate":  
[``https://unifiplaytvdrm.samsam123.tk/``](https://unifiplaytvdrm.samsam123.tk/) (Server hosted and mantained by @samleong123)  
If you can't use this link, or your IPTV client failed to get the playlist, [try this link](https://github.com/weareblahs/unifi-tv).  
Or if you prefer to do it manually (Save the file on your PC then go to the playtv@unifi website to get the VUID, see [here](https://github.com/weareblahs/unifi-tv#manual-instructions).  
Mantained and developed by @ohsem, @samleong123 and @weareblahs. [See project here](https://github.com/ohsem/my-iptv).  
  
  
EPG has been mirrored to ``https://unifiplaytv.samsam123.tk/epg``.

## Update: September 1 - Wait, where's Blue Ant Entertainment and Blue Ant Extreme?
 - [Click here to know why](https://www.rockentertainment.com/). Thank me later.

## Legal
This playlist is community-mantained, that means that it isn't mantained by Telekom Malaysia (unifi). The channels are directly taken from the playtv@unifi Web App (playtv.unifi.com.my) through their API. For the backend of the URL Generation page, we use the official playtv@unifi Authenticate API.    
This playlist is highly recommended for use by unifi TV / playtv@unifi users who have a valid subscription (as in most situations, the 30-second preview might be applied at the backend of their system - and unifi TV might be revoking this verification method after some period).

## Before you use this playlist
This playlist is geo-blocked to use in Malaysia only (which now includes Widevine keys for the playlist).
 - Tested on both ottweb.hypp.tv:8064 / 1.9.58.113:8063 Widevine servers.

The VOD playlist contains Third-Party content.

**Don't use this playlist if you want to login using your Facebook account** - for the username, you must use your phone number (for free users) or xxxx@iptv / xxxx@tvos for unifi TV subscribers.  

This playlist is **NOT for sale** - you can use it as a tutorial on YouTube or anywhere else.  

This playlist won't support emulators (such as Nox and BlueStacks) - mostly due to Widevine issues. See [this discussion thread](https://gist.github.com/weareblahs/89fc50e4011094628749b6362187e669#gistcomment-3770390) for more information. The only emulator that can support this type of playlist playback is **Android Studio** using the Android TV SDK. You can use a real device - no matter it's smartphones or TV boxes (sideload TiviMate if your TV Box isn't certified by Google) for this playlist.

Raspberry Pi 4 users? Use KonstaKANG's [Android TV Build](https://konstakang.com/devices/rpi4/LineageOS17.1-ATV/) for this playlist. Install / Sideload TiviMate or TVirl on your Raspberry Pi 4 through your flash drive. Subtitle works on both TiviMate and TVirl.  

LibreELEC usage? Download LibreELEC 9.2.8, which has full compability with Widevine CDM framework.

Old HyppTV / unifi TV boxes listed below are not compatible with this playlist due to TiviMate supports devices running on Android 5.0 or up. See the back of your box for the model.
 - HUAWEI EC6106V5 IP Set-Top-Box (Android 4.0)
 - HUAWEI EC6108V8 (Android 4.4)  

These unifi TV / HyppTV boxes can be used for TiviMate:
 - SKYWORTH unifi Plus Box (Android TV 9.0)

TiviMate 2.8.0 have some errors on this playlist:
 - When you import it and play it on some devices, it's normal for the first 5-7 days, and it won't play even you update it. To fix this, clear app data then reimport the playlist.

Errors with TiviMate:
 - Someone pointed out that this playlist won't support some LongTV TV Boxes installed with TiviMate. Other non-Widevine protected playlist worked well. (maybe due to lack of Widevine CDM?)
## Now testing devices!
If your device is compatible with this playlist, then [submit the form here](https://docs.google.com/forms/d/e/1FAIpQLSc9WuiemdFGiIJhkoqMtE73Ff74ts6D_lbGsRkFf-MZlxZJ7w/viewform?usp=sf_link).
## Channel List
For a list of channels, [see here](https://github.com/weareblahs/unifi-tv/blob/main/information/channels.md).
## Compatible Devices
See [here](https://t.me/utvrc/1677) for a list of confirmed compatible device that can run this playlist in 1080p.
## Discussing anything?
Join the discussion chat group here: https://t.me/utvrc - most of the updates will be posted there.
## Upcoming Tasks / Events
 - Following The Walt Disney Company's decision on closing some channels on South East Asia, these channels will be removed on this playlist starting October 1, 2021 ([source](https://www.theedgemarkets.com/article/disney-shut-down-most-its-tv-channels-southeast-asia-eyes-growth-streaming-services)):  
   - FOX Movies
   - FOX Family Movies
   - FOX Action Movies
   - FOXlife
   - FOX
   - FX
   - Nat Geo People
   - SCM Legend
   - FOX Sports 1
   - FOX Sports 2
   - FOX Sports 3  
These channels owned by Disney will have no effect:  
   - Nat Geo
   - Nat Geo Wild
   - SCM
   - Star Chinese Channel  
(EPG will also be affected when these channel closes)

## Guides
[See here](https://github.com/weareblahs/unifi-tv/blob/main/guide/guide.md)
## Any problem regarding the server?
Before you submit an issue, check the status of the servers [here](https://status.unifiplaytvdrm.samsam123.tk/). All servers are already listed here.
# Found new channels?
[Submit an issue here and tag "Found Channel"](https://github.com/weareblahs/unifi-tv/issues)

# What's this?
This is a m3u8 playlist file for Unifi playTV / Unifi TV. These links don't use normal HLS / MPEG-TS Livestreams, instead, using encrypted ones (MPEG-DASH). Remember, this guide is not used to bypass DRM and doesn't provide Free Links - you need your own unifi TV subscription.  
  
Note that this is also another way to watch Unifi TV through TiviMate through Telekom Malaysia's official servers. It is not required to install the official Unifi TV app.

# Frequent errors and how to fix it
## "DrmSessionException" appears on TiviMate
 - Go to Settings > Playlists > Update All Playlists

## Low quality video ranging from 240p to 480p even with high speed internet
 - Check your internet speed on fast.com or speedtest.net. If the internet speed is over 20-30Mbps, Change the channel, then change it back again. If the problem still occurs, then restart your TV / TV Box or decrease your internet traffic.
 - Tanix TX6 users can stream up to 240p.

## Fix TiviMate EPG: "No Information"
TiviMate users (especially using the 2.8.0 MOD version) may experience blank EPG (All channels showing "No information available") after a period of time. To fix this,
 - either uninstall TiviMate and install it again, or
 - Clear Data, then Clear Cache, then add the playlist again.

## Error Code 404
 - Restart Wi-Fi.
 - Restart your TV / TV Box.  
If these won't work, then wait for 5-10 minutes, then try again.

## No Subtitles on TVirl
There's a temporary fix: turning "Show Debug Info" on, then turn off this option. When you restart TVirl, you have to turn it on manually.
# Tested on what device / app?
Works well on Tivimate v2.8.0 and TVirl (Xiaomi Mi Box S / Xiaomi Mi TV Stick / Tivo Stream 4K).
  
UPDATE: I've asked the developer of TVirl and he said it will be fixed on the next update.

## What Internet Connection?
Tested on Unifi Air. It will play on multiple resolutions according to the Internet speed (ranging from 240p to 1080p (576p max on SD channels)). Unifi Fibre Broadband might get better speeds when playing.

# Do you have some of the screenshots for these channels?
[Screenshots from TiviMate (Channels with subtitles)](https://github.com/weareblahs/unifi-tv/blob/main/screenshots/tivimate.md)  
[Screenshots from generic MPD player](https://github.com/weareblahs/unifi-tv/blob/main/screenshots/mpd.md)

# Other features?
- Multiple Audio (if any, mostly Malay / Chinese / English / Other Languages)
- Subtitles (Mostly Malay / Chinese),
- Adaptive Resolution (automatic resolution switching according to your Internet connection)
- Channel Categories (thanks to @dysoct)
- Channel Numbers on OTT Navigator (Recently added)

# Known Technical Specs?
- 128Kbps AAC Audio
- H264 Video (Bitrate depends on resolution)
- Maximum Resolution is 1920x1080 (1024x576 max on SD channels)

# Is there cons?
- Unable to record
- DRM-protected Streams (Widevine / PlayReady)
- No timeshift although the link is capable of timeshifting (Timeshifting works on OTT Navigator by changing the setting for days to 1 and type to Auto - only works on free channels for free users, such as free-to-air channels)
- Channel won't follow channel number, but follows the channel sequence on Tivimate (also thanks to @dysoct)
- No Android emulator support (such as Bluestacks, Nox, Memuplay) (thanks to @arscenu for pointing out about this problem)
  - Will test it on Windows 11 when it start supporting Android apps

# Players that can play this playlist
- TiviMate (Highly recommended)
- TVirl (Subtitle errors)
- PVR Live (Channel Icons needs payment)
- [Native MPEG-DASH / HLS Player](https://chrome.google.com/webstore/detail/native-mpeg-dash-+-hls-pl/cjfbmleiaobegagekpmlhmaadepdeedn?hl=en) (You have to insert your Widevine license URL when requested)
- BitMovin Player
  - Download [this extension](https://chrome.google.com/webstore/detail/cors-unblock/lfhmikememgdcahcdlaciloancbhjino?hl=en) first
- OTT Navigator (Sometimes it got errors regarding license decryption, or 503 error - just refresh or change user-agent)
- Kodi (Needs to download Widevine CDM then follow the typical importing method that you used on m3u8 files)
  - Recommended version: 19.1 Matrix

# Known players that can't play this playlist
- VLC (Unencrypted DASH only)
- IPTV Smarters (Xtream codes only - no support of MPEG-DASH even if you use a Xtream Codes proxy to fake an Xtream Codes address)
- CosmiDVR (Signal Weak = 403 Access Denied error)
- Media Player Classic Home Cinema (uses youtube-dl to get mpd playlist, however, there's no option for license ID)
- Televizo (HLS / MPEG-TS streams only)
- ZalTV (HLS / MPEG-TS streams only)
- IPTV / IPTV Pro (HLS / MPEG-TS / Unencrypted MPD Streams only)
- IPTVX (HLS / MPEG-TS Streams only)

# Information
Please note that these links can be only accessed through a Widevine Server (for authorizing). Instructions below.  
**Note that the Widevine Server URL changes every 3-7 days**, so you have to follow the steps below regularly if you want to continue using this playlist.

## RECOMMENDED: 
Use the Direct URL for m3u8 option for automatic updating without getting the VUID manually. See the "Recommended option: Direct URL for m3u8" section.
# Manual Instructions
## Video Guides
[How to get AuthResp_VUID](https://streamable.com/ec7uk7)  
[unifigenerate Walkthrough](https://streamable.com/ii22ji)
## Get Widevine Server URL (Computer)
(Note that the previous instructions usually returns an "This Service Is Temporarily Unavailable. (632116)" error when constantly getting the Widevine key. Here are the new instructions (Thanks @samleong123):  
1. Go to [this page](https://playtv.unifi.com.my/EPG/WEBTV/index.html#/live-tv/).
2. Sign in with your Facebook account / Sign up for unifi playTV through Facebook / phone number / email address.
3. After signing in, follow these steps:
      - Right Click > Inspect Element.
      - Click "Application" > Local Storage > https://playtv.unifi.com.my.
      - Search for "AuthResp_VUID".
      - The result should look like this:  
        ![Result](https://pictr.com/images/2021/05/20/BP13Ex.png)
      - Copy the AuthResp_VUID.
4. Modifying the URL
      - Follow this template for the URL: ``https://ottweb.hypp.tv:8064?deviceId=[AuthResp_VUID]``  
        (Paste the AuthResp_VUID at the part of the URL which says [AuthResp_VUID] and remove the quotes ("").
      - Copy it. we will use the URL at the next step.
## Get Widevine Server URL (Smartphone by using Google Chrome) - Credits to @Arsyad1105
[Follow this method](https://github.com/weareblahs/unifi-tv/issues/11).
## Download the file and modify the inputstream.adaptive.license_key to the Widevine Server URL
1. Download "unifitv.ejs" by [clicking here](https://github.com/weareblahs/unifi-tv/raw/main/dev/unifitv.ejs).
   - Remember to rename "unifitv.ejs" to "unifi.m3u8".
3. Open it with Notepad. (SHORTCUT: Windows key + R > notepad > Enter)
4. In notepad, press "Ctrl + H" (Replace).
      - In "Find What", type in "https://ottweb.hypp.tv:8064?deviceId=<%= vuid %>".
      - In "Replace With", paste the URL which we got at the previous step.
5. Save it. Now you have a m3u8 file ready to import.

## Importing into compatible IPTV players
### Before we start the importing
NOTE: This playlist only supports TiviMate, PVR Live and TVirl.
1. Upload the file to Dropbox / Github / Any file hosting service that support direct link
     - You can also use HFS. I'm using HFS for m3u8 Transfer through local network. [See the guide by clicking here](https://github.com/weareblahs/unifi-tv/blob/main/guide/hfs.md)
     - Offline options: Use File Commander to transfer the playlist to your TV / TV Box
### Uploading your playlist into Dropbox for Tivimate Access
1. Sign in into Dropbox
2. Upload the saved m3u8 file to your Dropbox.
3. Hover on the file name in Dropbox, click Share, then click Create from "Create then Copy Link".
4.  Click on "Copy Link". (the Dropbox link will be copied in your clipboard)
5. Open any text editor, paste it, then change "dl=0" into "dl=1" (at the end of the link).
     -  (Note that you have to memorize this link OR copy this link to your TV at the next step)
6. Done!
### Importing your playlist into Tivimate
1. After opening the app, select "Add Playlist".
2. Select "Enter URL", then type in the link that you've generated.
3. Select "Next".
4. Follow the steps. EPG should be automatically detected from the m3u8 file.
5. You're ready to watch!

## EPG Credits
EPG for unifi TV in-house channels (such as HyppSensasi, unifi Sports) and some Indian channels (such as SET, Polimer) has been made available on the EPG thanks to @hantu08 (Khalis) on Telegram.
# No EPG?
Check the XMLTV / EPG settings of your IPTV app - is there an EPG source called "https://weareblahs.github.io/epg/unifitv.xml" (or unifitv on some clients)? If not, then manually add "https://weareblahs.github.io/epg/unifitv.xml" to one of your EPG source.
